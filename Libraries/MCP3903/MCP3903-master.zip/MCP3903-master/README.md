Arduino Library for MCP3903 A/D Converter

An Arduino Library for MCP3903 A/D Converter. More details can be found at <a href="http://www.kerrywong.com/2014/05/10/mcp3903-library/">MCP3903 Library</a>.
